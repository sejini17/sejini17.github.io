module.exports = {
  "transpileDependencies": [
    "vuetify"
  ],

  outputDir: '../resources/static'
}